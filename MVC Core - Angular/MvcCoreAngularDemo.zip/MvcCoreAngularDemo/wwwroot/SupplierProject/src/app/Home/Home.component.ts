import { Component } from '@angular/core';

@Component({
  templateUrl: './Home.view.html'
})
export class HomeComponent {
  page = 'Home Page';
}

 