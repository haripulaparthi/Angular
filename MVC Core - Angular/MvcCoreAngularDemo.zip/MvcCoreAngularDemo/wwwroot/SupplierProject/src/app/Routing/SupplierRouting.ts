import {SupplierComponent} from '../Supplier/Supplier.component'

export const SupplierRouting =[
    {path: 'Add', component: SupplierComponent}
]