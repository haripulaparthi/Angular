import {CustomerComponent} from '../Customer/Customer.component'

export const CustomerRouting =[
    {path: 'Add', component: CustomerComponent}
]