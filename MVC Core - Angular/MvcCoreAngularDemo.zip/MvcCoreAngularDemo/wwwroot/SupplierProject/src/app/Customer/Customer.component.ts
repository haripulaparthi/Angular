import { Component } from '@angular/core';

@Component({
  templateUrl: './Customer.view.html'
})
export class CustomerComponent {
  page = 'Customer Page';
}

 